# Acme Billing

Tiny Python billing helpers used by the loop-engineering demo.

```bash
python -m pytest -q
```

Known open tickets live in the issue tracker the coding agent receives.
